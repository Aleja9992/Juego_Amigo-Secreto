let nombres= [];

function agregarAmigo(){
    let amigo = document.getElementById("amigo").value;
    nombres.push(amigo);
    console.log(nombres);
    document.getElementById("amigo").value = "";
    document.getElementById("amigo").focus();
    return false;
}


function mostrarAmigos() {
   
    let lista = document.getElementById("listaAmigos");
   
    lista.innerHTML = "";
    
    for (let i = 0; i < nombres.length; i++) {
        let li = document.createElement("li");
        li.textContent = nombres[i];
        lista.appendChild(li);
    }
}

function sortearAmigo() {
    
    if (nombres.length === 0) {
        document.getElementById("resultado").innerHTML = "No hay amigos para sortear.";
        return;
    }
    
    let indice = Math.floor(Math.random() * nombres.length);
    
    let amigoSorteado = nombres[indice];
    
    document.getElementById("resultado").innerHTML = `El amigo sorteado es: <strong>${amigoSorteado}</strong>`;
}